<?php



// Silence is golden.