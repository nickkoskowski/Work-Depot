/* global QTags */
// version 2.0 - original version for WordPress versions 3.3 and greater
QTags.addButton( 'Subscribe2', 'Subscribe2', '[subscribe2]' );